export const DEFAULT_THEME = "dark";
